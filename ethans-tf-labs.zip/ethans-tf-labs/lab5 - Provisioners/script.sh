
mkdir /tmp/provisioner-demo